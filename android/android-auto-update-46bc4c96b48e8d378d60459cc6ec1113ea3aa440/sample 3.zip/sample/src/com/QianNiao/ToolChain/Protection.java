package com.QianNiao.ToolChain;

public class Protection {
	//检查包签名是否包含原始签名数据的一部分，包含说明没有进行二次打包
	public static Boolean CheckSignature(){
		return false;
	}
}
