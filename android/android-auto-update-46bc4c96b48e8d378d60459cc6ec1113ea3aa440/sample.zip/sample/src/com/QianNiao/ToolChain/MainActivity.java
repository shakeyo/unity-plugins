package com.QianNiao.ToolChain;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;


public class MainActivity extends UnityPlayerActivity {
	Context mContext = null;  
	Activity mActivity=null; 
	
	private final int MSG_STYLE_OK = 0;
	private final int MSG_STYLE_CANCEL = 1;
	private final int MSG_STYLE_OKCANCEL = 2;
	private final int MSG_STYLE_YESNO = 3;
	
	@Override      
    protected void onCreate(Bundle savedInstanceState) {         
        super.onCreate(savedInstanceState);     
        
        mActivity=this;          
        mContext = this;     
        
        try {  
            //获取包管理  
            PackageManager manager = this.getPackageManager();  
              
            /** 
             * 判断软件是否安装 
             */  
            List<PackageInfo> packages=manager.getInstalledPackages(0);  
            System.out.println("packages:"+packages.size());
            
            for(PackageInfo info:packages){  
                //获取已经安装的软件的包名  
                System.out.println("已经安装的软件的包名："+info.packageName+" src:"+info.applicationInfo.sourceDir+" dir:"+info.applicationInfo.publicSourceDir);  
                
            }  
              
            /** 
             * PackageInfo,通过反射获取PackageInfo中的属性 
             */  
            Class<?> cl=PackageInfo.class;  
            Field[] fields=cl.getDeclaredFields();  
            for(Field f:fields){  
                f.setAccessible(true);  
                System.out.println("PackageInfo参数："+f.getName()+"-"+f.get(packages.get(0)));  
            }  
              
            
            /** 
             * 遍历apk包内的文件 
             */  
            //通过包名获取应用信息  
            ApplicationInfo info = manager.getApplicationInfo(  
                    this.getPackageName(), 0);  
            System.out.println("getPackageName："+this.getPackageName());  
            //通过安装路径读取这个apk压缩包  
            ZipFile file=new ZipFile(info.sourceDir);   
            //获取压缩文件内明细  
            Enumeration<?> enumeration=file.entries();   
              
            while(enumeration.hasMoreElements()){  
                //获取下一个并转成ZipEntry类型  
                ZipEntry entry=(ZipEntry)enumeration.nextElement();   
                //获取文件名，包含路径，例如：assets/*  
                System.out.println("文件相对压缩包路径名："+entry.getName());   
                //获取文件的输入流  
                InputStream input=file.getInputStream(entry);   
            }  
              
            /**  
             * ApplicationInfo,通过反射获取ApplicationInfo中的属性  
             */  
            /*cl=info.getClass();  
            fields=cl.getDeclaredFields();  
            for(Field f:fields){  
                f.setAccessible(true);  
                System.out.println("ApplicationInfo参数："+f.getName()+"-"+f.get(info));  
            }*/  
        } catch (Exception ex) {  
            ex.printStackTrace();  
        }
	
        
        /*try {
        	PackageInfo pkgInfo = this.getPackageManager().getPackageInfo(mContext.getPackageName(), PackageManager.GET_SIGNATURES);
        	for(int i=0; i<pkgInfo.signatures.length; i++){
            	Log.d("UnityActivity", String.format("signatures %d : %s",i, pkgInfo.signatures[i].toCharsString()));
        	}
        	
        	//this.getPackageManager().
        	//this.getPackageManager().checkSignatures(pkg1, pkg2)
        	
        	
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    }
	
	@Override
	protected void onDestroy(){
		super.onDestroy();
		
		//PayManager.getInstance().UnInit();
	}
	
	private PayManager payMgr;
	
	public void InitPaySDK(int mode, String appID, String secret, String wechatID, String callbackObj ,String callback){
		Log.d("UnityActivity", "------ InitSDK ------");
		
		payMgr = new PayManager();
		payMgr.Init(mContext, mode, appID, secret, wechatID, callbackObj, callback);
	}
	
	public void UnInitPaySDK(){
		payMgr.UnInit();
		payMgr = null;
	}
	
    public void SDKPay(
    		String title, 
    		String bill, 
    		int amount,
    		int channel,
    		String optional
			){

    	Log.d("UnityActivity", "------ StartPay begin ------");
   
    	payMgr.DoPay(title, bill, amount, channel, optional);
    	
		Log.d("UnityActivity", "------ StartPay end ------");
	}
    
    
    public void DownloadAndUpdate(
			 String url, 
			 String storge,
			 Boolean showNotify
			){
    	UpdateManager updater = new UpdateManager(mContext);
    	//updater.showNotification(title, desc);
    	updater.Download(url, storge);
	}
    
    public void MsgBox(final String title, final String msg, int mode, final String callbackObj, final String callback){
    	AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);                      
        dlgAlert.setMessage(msg);
        dlgAlert.setTitle(title);            
        
        switch(mode){
        case MSG_STYLE_OK:{
        	dlgAlert.setPositiveButton("确定", new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface dialog, int whichButton) { 
                    setResult(RESULT_OK);//确定按钮事件 
                    //finish(); 
                    
                    UnityPlayer.UnitySendMessage(callbackObj, callback, RESULT_OK+"");
                }
            }); 
        	break;
        }
        case MSG_STYLE_CANCEL:{
        	dlgAlert.setPositiveButton("取消", new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface dialog, int whichButton) { 
                    setResult(RESULT_CANCELED);//确定按钮事件 
                    //finish(); 
                    
                    UnityPlayer.UnitySendMessage(callbackObj, callback, RESULT_CANCELED+"");
                }
            }); 
        	break;
        }
        case MSG_STYLE_OKCANCEL:{
        	dlgAlert.setNegativeButton("确定", new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface dialog, int whichButton) { 
                    setResult(RESULT_OK);//确定按钮事件 
                    //finish(); 
                    
                    UnityPlayer.UnitySendMessage(callbackObj, callback, RESULT_OK+"");
                }
            }); 
        	dlgAlert.setPositiveButton("取消", new DialogInterface.OnClickListener() { 
                public void onClick(DialogInterface dialog, int whichButton) { 
                    setResult(RESULT_CANCELED);//确定按钮事件 
                    //finish(); 
                    
                    UnityPlayer.UnitySendMessage(callbackObj, callback, RESULT_CANCELED+"");
                }
            }); 
        	break;
        }
        }
       
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
    
}
