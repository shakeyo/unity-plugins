package com.UGS.NativePlugins;

import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;
import com.unity3d.player.UnityPlayerNativeActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

public class WXEntryActivity extends Activity implements IWXAPIEventHandler {

	private IWXAPI mWeixinAPI;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onCreate");
		
		mWeixinAPI = WXAPIFactory.createWXAPI(this, WXAuth.AppID, false);
		mWeixinAPI.registerApp(WXAuth.AppID);
		mWeixinAPI.handleIntent(getIntent(), this);
	}
	
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        Log.w(DefineConst.LOG_TAG, "WxAuthActivity onDestroy");

        if (mWeixinAPI != null)
        	mWeixinAPI.detach();
    }

	@Override
	protected void onNewIntent(Intent intent) {
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onNewIntent");
		super.onNewIntent(intent);
		setIntent(intent);
		mWeixinAPI.handleIntent(intent, this);
		finish();
	}

	@Override
	public void onReq(BaseReq arg0) {
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onReq");
	}

	@Override
	public void onResp(BaseResp resp) {
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp");
		
		SendAuth.Resp authResp = ((SendAuth.Resp) resp);

		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp errCode:" + resp.errCode);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp errStr:" + resp.errStr);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp code:" + authResp.code);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp state:" + authResp.state);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp lang:" + authResp.lang);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp openId:" + authResp.openId);
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity onResp country:" + authResp.country);

		/*switch (resp.errCode) {
		case BaseResp.ErrCode.ERR_OK:
			Toast.makeText(this, "微信确认登录返回的code：" + authResp.code, Toast.LENGTH_LONG).show();
			break;
		case BaseResp.ErrCode.ERR_USER_CANCEL:
			Toast.makeText(this, "发送取消", Toast.LENGTH_LONG).show();
			break;
		case BaseResp.ErrCode.ERR_AUTH_DENIED:
			Toast.makeText(this, "发送拒绝", Toast.LENGTH_LONG).show();
			break;
		default:
			break;
		}
*/
		String code = authResp.code;
		Intent intent = new Intent();
		intent.setAction(DefineConst.BROADCAST_ACTION_WEIXIN_TOKEN);
		intent.putExtra("errCode", authResp.errCode);
		intent.putExtra("code", code);

		if (android.os.Build.VERSION.SDK_INT >= 12) {
			intent.setFlags(32);// 3.1以后的版本需要设置Intent.FLAG_INCLUDE_STOPPED_PACKAGES
		}

		LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this);
		lbm.sendBroadcast(intent);

		this.finish();
		
		Log.w(DefineConst.LOG_TAG, "WxAuthActivity finish");
	}

}
