package com.UGS.NativePlugins;

public class DefineConst {

	public static final String LOG_TAG = "UnityActivity";
	
	
	public static String BROADCAST_ACTION_WEIXIN_TOKEN = "";

	public static String BUGLY_APP_ID = "900009322";
	

}
