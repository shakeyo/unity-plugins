package com.UGS.NativePlugins;

import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelmsg.SendAuth;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class WXAuth extends BroadcastReceiver {

	private IWXAPI mWeixinAPI;
	private String mCallbackObj;
	private String mCallback;
	//private String mAppID;
	private Context mContext;

	public static String WX_ACCESS_TOKEN = "access_token";
	public static String WX_OPEN_ID = "openid";
	public static String WX_REFRESH_TOKEN = "refresh_token";
	public static String WX_UNION_ID = "unionid";
	public static String WX_SCOPE_STR = "snsapi_userinfo";
	public static String WX_STATE_STR = "wx_login";
	
	public static String AppID = "";
	
	private ProgressDialog loadingDialog;
	
	public WXAuth(Context context, String appID) {
		
		mWeixinAPI = WXAPIFactory.createWXAPI(context, appID, false);
		if (!mWeixinAPI.isWXAppInstalled()) {
			// 提醒用户没有按照微信
			return;
		}

		mWeixinAPI.registerApp(appID);

		mContext = context;
		AppID = appID;
		
		loadingDialog = new ProgressDialog(context);
		loadingDialog.setMessage("处理中，请稍候...");
		loadingDialog.setIndeterminate(true);
		loadingDialog.setCancelable(false);
		loadingDialog.show();
		
		
		Log.w(DefineConst.LOG_TAG, "WxAuth init. appid:"+appID);
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.w(DefineConst.LOG_TAG, "WxAuth onReceive:"+intent.getAction());

		if (intent.getAction().equals(DefineConst.BROADCAST_ACTION_WEIXIN_TOKEN)) {
			int errCode = intent.getExtras().getInt("errCode");
			String code = intent.getExtras().getString("code");
			Log.w(DefineConst.LOG_TAG, "获取错误码：" + errCode);
			
			String result = String.format("%d:%s", errCode, code);
			UnityPlayer.UnitySendMessage(mCallbackObj, mCallback, result);
		}
		
		loadingDialog.dismiss();
		
		Activity act = (Activity)mContext;
		act.finish();
	}

	public void SendAuth(String cbObj, String cb) {
		if (!IsSupported()) {
			Toast.makeText(mContext, "没有安装微信或者微信版本不支持", Toast.LENGTH_LONG).show();
			return;
		}
		
		mCallbackObj = cbObj;
		mCallback = cb;

		SendRequest();
	}
	
	private void SendRequest() {
		Log.w(DefineConst.LOG_TAG, "WxAuth SendRequest");
		
		SendAuth.Req req = new SendAuth.Req();
		req.scope = WX_SCOPE_STR;
		req.state = WX_STATE_STR;
		mWeixinAPI.registerApp(AppID);
		mWeixinAPI.sendReq(req);
	}

	public Boolean IsSupported() {
		return mWeixinAPI.isWXAppInstalled() && mWeixinAPI.isWXAppSupportAPI();
	}

}
