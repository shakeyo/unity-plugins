package com.UGS.NativePlugins;

import com.tencent.mm.sdk.modelbase.BaseResp;
import com.unity3d.player.UnityPlayer;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;


public class SDKAuth extends Activity {
	
	private WXAuth mWXAuth;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Log.d(DefineConst.LOG_TAG, "Create SDKAuth Activity!!!!!!!!!!");
		
		try {
			String callbackObj = this.getIntent().getStringExtra("CallbackObj");
			String callback = this.getIntent().getStringExtra("Callback");
			String wxAppID = this.getIntent().getStringExtra("WXAppID");

			Log.d(DefineConst.LOG_TAG, "init SDKAuth:"+wxAppID);
			
			LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(this); 
			IntentFilter filter = new IntentFilter(); 
			filter.addAction(DefineConst.BROADCAST_ACTION_WEIXIN_TOKEN); 
			
			mWXAuth = new WXAuth(this, wxAppID);
			lbm.registerReceiver(mWXAuth,filter);
			
			mWXAuth.SendAuth(callbackObj, callback);
			
		} catch (Exception e) {
			Log.d(DefineConst.LOG_TAG, "init auth sdk failed: " + e.getMessage());
		}
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		Log.d(DefineConst.LOG_TAG, "SDKAuth Activity onDestroy");
	}
	
	public static void WXAuth(String appID, String callbackObj, String callback){
		
		Log.d(DefineConst.LOG_TAG, "WXLogin");
		
		Intent intent = new Intent(UnityPlayer.currentActivity,SDKAuth.class);
		intent.putExtra("WXAppID", appID);
    	intent.putExtra("CallbackObj", callbackObj);
    	intent.putExtra("Callback", callback);
    	UnityPlayer.currentActivity.startActivity(intent);
	}
	
	
}
